const colors = {
    primary: '#1976D2'
}
  
export {
    colors
}
  